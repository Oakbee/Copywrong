import TelegramBot from 'node-telegram-bot-api';
import { VideoProcessor } from './videoProcessor.js';
import { downloadFile } from './utils/download.js';
import { logger } from './utils/logger.js';
import fs from 'fs-extra';
import path from 'path';

const TOKEN = '8032886406:AAF34VhY6DDn3ItTivpKoAQWlcwr1wNkEPo';
const bot = new TelegramBot(TOKEN, { polling: true });
const videoProcessor = new VideoProcessor();

// Ensure temp directories exist
await fs.ensureDir('./temp/downloads');
await fs.ensureDir('./temp/processed');

bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  
  try {
    // Handle video messages
    if (msg.video) {
      logger.info(`Received video from chat ${chatId}`);
      await handleVideoMessage(msg, chatId);
    }
    // Handle video notes (circles)
    else if (msg.video_note) {
      logger.info(`Received video note from chat ${chatId}`);
      await handleVideoNote(msg, chatId);
    }
    // Handle documents that might be videos
    else if (msg.document && msg.document.mime_type?.startsWith('video/')) {
      logger.info(`Received video document from chat ${chatId}`);
      await handleVideoDocument(msg, chatId);
    }
    // Handle start command
    else if (msg.text === '/start') {
      await bot.sendMessage(chatId, `
🎥 *Video Duplicate Remover Bot*

Send me any video and I'll process it to avoid duplicate content detection on social media platforms.

*Features:*
• Subtle cropping and scaling
• Quality adjustments  
• Overlay effects
• Metadata removal
• Multiple processing options

Just send a video to get started!
      `, { parse_mode: 'Markdown' });
    }
    // Handle help command
    else if (msg.text === '/help') {
      await bot.sendMessage(chatId, `
*How to use:*

1️⃣ Send me any video file
2️⃣ I'll automatically process it with anti-duplicate techniques
3️⃣ Receive your modified video ready for reposting

*Processing includes:*
• Crop & scale adjustments
• Subtle filter overlays
• Quality/compression changes
• Metadata stripping
• Frame rate adjustments

*Supported formats:* MP4, MOV, AVI, MKV, WebM
      `, { parse_mode: 'Markdown' });
    }
    else if (msg.text && !msg.text.startsWith('/')) {
      await bot.sendMessage(chatId, 'Please send me a video file to process. Use /help for instructions.');
    }
  } catch (error) {
    logger.error(`Error handling message: ${error.message}`);
    await bot.sendMessage(chatId, '❌ Sorry, there was an error processing your message. Please try again.');
  }
});

async function handleVideoMessage(msg, chatId) {
  const video = msg.video;
  await processVideo(video, chatId, 'video');
}

async function handleVideoNote(msg, chatId) {
  const videoNote = msg.video_note;
  await processVideo(videoNote, chatId, 'video_note');
}

async function handleVideoDocument(msg, chatId) {
  const document = msg.document;
  await processVideo(document, chatId, 'document');
}

async function processVideo(videoObj, chatId, type) {
  let statusMsg;
  
  try {
    // Send initial processing message
    statusMsg = await bot.sendMessage(chatId, '⏳ Processing your video...');
    
    // Download the video
    const fileId = videoObj.file_id;
    const fileInfo = await bot.getFile(fileId);
    const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${fileInfo.file_path}`;
    
    await bot.editMessageText('⬇️ Downloading video...', {
      chat_id: chatId,
      message_id: statusMsg.message_id
    });
    
    const inputPath = await downloadFile(fileUrl, './temp/downloads');
    
    await bot.editMessageText('🎨 Applying anti-duplicate processing...', {
      chat_id: chatId,
      message_id: statusMsg.message_id
    });
    
    // Process the video to avoid duplicate detection
    const outputPath = await videoProcessor.processForAntiDuplicate(inputPath);
    
    await bot.editMessageText('📤 Uploading processed video...', {
      chat_id: chatId,
      message_id: statusMsg.message_id
    });
    
    // Send the processed video back
    await bot.sendVideo(chatId, outputPath, {
      caption: '✅ Video processed successfully! This version should avoid duplicate content detection.',
      reply_to_message_id: statusMsg.message_id - 1 // Reply to original video
    });
    
    // Delete the status message
    await bot.deleteMessage(chatId, statusMsg.message_id);
    
    // Clean up temporary files
    await fs.remove(inputPath);
    await fs.remove(outputPath);
    
    logger.info(`Successfully processed video for chat ${chatId}`);
    
  } catch (error) {
    logger.error(`Error processing video: ${error.message}`);
    
    if (statusMsg) {
      await bot.editMessageText('❌ Failed to process video. Please try again with a different file.', {
        chat_id: chatId,
        message_id: statusMsg.message_id
      });
    } else {
      await bot.sendMessage(chatId, '❌ Failed to process video. Please try again.');
    }
  }
}

// Handle polling errors
bot.on('polling_error', (error) => {
  logger.error(`Polling error: ${error.message}`);
});

logger.info('🤖 Telegram Video Bot started successfully!');
logger.info('Send videos to process them for anti-duplicate posting');