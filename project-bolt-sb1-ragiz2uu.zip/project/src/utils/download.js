import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { logger } from './logger.js';

export async function downloadFile(url, downloadDir) {
  const fileName = `download_${uuidv4()}.mp4`;
  const filePath = path.join(downloadDir, fileName);
  
  try {
    logger.info(`Downloading file from: ${url}`);
    
    const response = await axios({
      method: 'GET',
      url: url,
      responseType: 'stream',
      timeout: 300000, // 5 minutes timeout
    });
    
    const writer = fs.createWriteStream(filePath);
    response.data.pipe(writer);
    
    return new Promise((resolve, reject) => {
      writer.on('finish', () => {
        logger.info(`File downloaded successfully: ${filePath}`);
        resolve(filePath);
      });
      
      writer.on('error', (error) => {
        logger.error(`Download error: ${error.message}`);
        reject(error);
      });
    });
    
  } catch (error) {
    logger.error(`Failed to download file: ${error.message}`);
    throw new Error(`Download failed: ${error.message}`);
  }
}