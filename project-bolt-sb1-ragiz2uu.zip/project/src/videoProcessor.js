import ffmpeg from 'fluent-ffmpeg';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { logger } from './utils/logger.js';
import fs from 'fs-extra';

export class VideoProcessor {
  constructor() {
    this.isLoaded = true; // No loading needed for fluent-ffmpeg
  }

  async loadFFmpeg() {
    // No loading needed for fluent-ffmpeg
    return Promise.resolve();
  }

  async processForAntiDuplicate(inputPath) {
    const outputPath = path.join('./temp/processed', `processed_${uuidv4()}.mp4`);
    
    try {
      // Ensure output directory exists
      await fs.ensureDir(path.dirname(outputPath));
      
      // Apply multiple anti-duplicate techniques
      const filters = this.generateAntiDuplicateFilters();
      
      return new Promise((resolve, reject) => {
        ffmpeg(inputPath)
          .videoFilters(filters)
          .videoCodec('libx264')
          .audioCodec('aac')
          .audioBitrate('128k')
          .outputOptions([
            '-preset medium',
            '-crf 23',
            '-movflags +faststart',
            '-map_metadata -1' // Remove metadata
          ])
          .output(outputPath)
          .on('end', () => {
            logger.info(`Video processed successfully: ${outputPath}`);
            resolve(outputPath);
          })
          .on('error', (err) => {
            logger.error(`Video processing failed: ${err.message}`);
            reject(err);
          })
          .run();
      });
      
    } catch (error) {
      logger.error(`Video processing failed: ${error.message}`);
      throw error;
    }
  }

  generateAntiDuplicateFilters() {
    // Randomize processing parameters for each video
    const cropPercentage = 0.02 + Math.random() * 0.03; // 2-5% crop
    const scaleAdjustment = 0.98 + Math.random() * 0.04; // 98-102% scale
    const brightnessAdj = -0.05 + Math.random() * 0.1; // -0.05 to +0.05
    const contrastAdj = 0.95 + Math.random() * 0.1; // 0.95 to 1.05
    const saturationAdj = 0.95 + Math.random() * 0.1; // 0.95 to 1.05
    
    const filters = [
      // Subtle crop to change dimensions
      `crop=iw*(1-${cropPercentage}):ih*(1-${cropPercentage})`,
      
      // Slight scale adjustment
      `scale=iw*${scaleAdjustment}:ih*${scaleAdjustment}`,
      
      // Color adjustments
      `eq=brightness=${brightnessAdj}:contrast=${contrastAdj}:saturation=${saturationAdj}`,
      
      // Add subtle noise (very light)
      `noise=alls=1:allf=t`,
      
      // Slight unsharp mask
      `unsharp=5:5:0.3:3:3:0.1`,
    ];
    
    // Randomly add additional effects
    if (Math.random() > 0.5) {
      // Add subtle vignette
      filters.push('vignette=PI/6');
    }
    
    if (Math.random() > 0.7) {
      // Add very subtle film grain
      filters.push('noise=alls=2:allf=t+u');
    }
    
    if (Math.random() > 0.6) {
      // Slight gamma adjustment
      const gamma = 0.9 + Math.random() * 0.2; // 0.9 to 1.1
      filters.push(`lutyuv=y=gammaval(${gamma})`);
    }
    
    return filters;
  }

  // Alternative method using different processing approach
  async processWithAlternativeMethod(inputPath) {
    const outputPath = path.join('./temp/processed', `alt_processed_${uuidv4()}.mp4`);
    
    try {
      await fs.ensureDir(path.dirname(outputPath));
      
      // Alternative processing with different parameters
      const fps = 29.97; // Slightly different frame rate
      const quality = 22 + Math.floor(Math.random() * 3); // CRF 22-24
      
      const filters = [
        `scale=iw*0.99:ih*0.99`, // 1% scale down
        `pad=iw*1.01:ih*1.01:(ow-iw)/2:(oh-ih)/2:black`, // Add thin black borders
        `eq=brightness=0.02:contrast=1.01`, // Subtle adjustments
        `noise=alls=1:allf=t`
      ];
      
      return new Promise((resolve, reject) => {
        ffmpeg(inputPath)
          .videoFilters(filters)
          .fps(fps)
          .videoCodec('libx264')
          .audioCodec('aac')
          .audioBitrate('128k')
          .outputOptions([
            '-preset slow',
            `-crf ${quality}`,
            '-movflags +faststart',
            '-map_metadata -1'
          ])
          .output(outputPath)
          .on('end', () => {
            logger.info(`Alternative processing completed: ${outputPath}`);
            resolve(outputPath);
          })
          .on('error', (err) => {
            logger.error(`Alternative processing failed: ${err.message}`);
            reject(err);
          })
          .run();
      });
      
    } catch (error) {
      logger.error(`Alternative processing failed: ${error.message}`);
      throw error;
    }
  }
}